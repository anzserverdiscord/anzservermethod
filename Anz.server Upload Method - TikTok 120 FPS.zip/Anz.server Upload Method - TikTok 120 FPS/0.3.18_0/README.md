# Anz.server Extension

Welcome to **Anz.server Extension**, an extension created to improve the experience of creators and users.

This extension is a project developed by **Mathkasa**, with occasional help from AI to solve some bugs and technical issues. The main design, development, features, and improvements were created by myself.

---

# 📥 Extension Installation

## 1. Download the extension files

Get the complete extension folder from our official Discord server:

🔗 Discord: https://discord.gg/NKrWGDGKt

All latest versions and updates will always be available on our Discord server.

---

## 2. Open Chrome Extensions

1. Open **Google Chrome** or any Chromium-based browser (Edge, Brave, Arc...)
2. Go to the address bar:

```text
chrome://extensions
```

3. Enable **Developer mode** in the top right corner.

---

## 3. Install the extension

1. Click:

```text
Load unpacked
```

2. Select the extension folder:

```text
Anz.server Upload Method - TikTok 120 FPS / 0.3.17_0
```

3. Select the folder containing the extension files.

4. The extension should now appear in your browser extensions list.

---

# ⚙️ How to Use

1. Enable the extension from your browser extension menu.
2. Open the extension settings if available.
3. Use the features provided by the extension.

Follow the instructions provided with each update to correctly use new features.

---

# 🔄 Updates

All future updates, bug fixes, and improvements will be released directly on our Discord server.

On Discord, you will find:

- 📦 Latest extension versions
- 🛠️ Bug fixes and patches
- 📚 Update information
- 💬 Support if you have any issues
- 📁 Extension files ready to install

---

# 💻 Development

This extension was developed by:

👑 **Mathkasa**

AI was only used occasionally to help solve certain bugs and technical problems during development.

The idea, design, development, features, and improvements of this project were created and made by Mathkasa.

---

# 🔗 Links

Official Discord server:

https://discord.gg/NKrWGDGKt

---

Thank you for using **Anz.server Extension** 💙






# Anz.server Extension

Bienvenue sur **Anz.server Extension**, une extension développée pour améliorer l'expérience des créateurs et des utilisateurs.

Cette extension est un projet développé par **Mathkasa** avec l'aide ponctuelle d'une IA pour résoudre certains bugs et problèmes techniques. La conception, le développement et les améliorations principales ont été réalisés par moi-même.

---

# 📥 Installation de l'extension

## 1. Télécharger les fichiers

Récupère le dossier complet de l'extension depuis notre serveur Discord :

🔗 Discord : https://discord.gg/NKrWGDGKt

Les dernières versions et mises à jour seront toujours disponibles sur le serveur.

---

## 2. Ouvrir les extensions Chrome

1. Ouvre **Google Chrome** ou un navigateur compatible Chromium (Edge, Arc, Brave...)
2. Va dans la barre d'adresse :

```
chrome://extensions
```

3. Active le **Mode développeur** en haut à droite.

---

## 3. Installer l'extension

1. Clique sur :

```
Charger l'extension non empaquetée
```

2. Sélectionne le dossier de l'extension :

```
Anz.server Upload Method - TikTok 120 FPS / 0.3.17_0 / selectionner le dossier
```

3. L'extension devrait apparaître dans ta liste.

---

# ⚙️ Utilisation

1. Active l'extension depuis le menu des extensions.
2. Configure les options disponibles.
3. Utilise les fonctionnalités proposées par l'extension.

---

# 🔄 Mises à jour

Toutes les nouvelles versions, corrections de bugs et améliorations seront publiées directement sur notre serveur Discord.

Sur Discord vous retrouverez :

- 📦 Les nouvelles versions de l'extension
- 🛠️ Les correctifs
- 📚 Les informations des mises à jour
- 💬 Le support en cas de problème

---

# 💻 Développement

Cette extension a été développée par :

👑 **Mathkasa**

Avec l'utilisation occasionnelle d'une IA uniquement pour aider à résoudre certains bugs et problèmes de développement.

Le projet, son fonctionnement et ses améliorations ont été réalisés par Mathkasa.

---

# 🔗 Liens

Discord officiel :

https://discord.gg/NKrWGDGKt

---

Merci d'utiliser **Anz.server Extension** 💙