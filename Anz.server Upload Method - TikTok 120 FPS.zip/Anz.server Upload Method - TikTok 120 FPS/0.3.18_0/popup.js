const API_BASE = 'https://api.midx.app';

const toggle = document.getElementById('enabledToggle');
const toggleNote = document.getElementById('toggleNote');
const serverPill = document.getElementById('serverPill');
const serverText = document.getElementById('serverText');
const versionTag = document.getElementById('versionTag');
const tipsStep = document.getElementById('tipsStep');
const tipsPopover = document.getElementById('tipsPopover');

// Son du bouton ON/OFF
const clickSound = new Audio(chrome.runtime.getURL("icons/Anz.server click.wav"));
clickSound.volume = 1;

function setToggleNote(enabled) {
  toggleNote.textContent = enabled
    ? 'Upload Method is active'
    : 'TikTok will receive the original file';
}

function setServerState(state, label) {
  serverPill.classList.remove('ok', 'bad');
  if (state) serverPill.classList.add(state);
  serverText.textContent = label;
}

function hasChromeStorage() {
  return typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
}

function setVersion() {
  try {
    const manifest = chrome.runtime.getManifest();
    const label = manifest.version_name || manifest.version;
    versionTag.textContent = label ? `v${label}` : 'v0.3.15 beta';
  } catch {
    versionTag.textContent = 'v0.3.15 beta';
  }
}

setVersion();

if (hasChromeStorage()) {
  chrome.storage.local.get({ midxEnabled: true }, (state) => {
    toggle.checked = state.midxEnabled !== false;
    setToggleNote(toggle.checked);
  });
} else {
  setToggleNote(toggle.checked);
}

// Son + sauvegarde du bouton ON/OFF
toggle.addEventListener('change', () => {
  clickSound.currentTime = 0;
  clickSound.play().catch(() => {});

  if (hasChromeStorage()) {
    chrome.storage.local.set({ midxEnabled: toggle.checked });
  }

  setToggleNote(toggle.checked);
});

function setTipsOpen(open) {
  if (!tipsStep || !tipsPopover) return;

  tipsPopover.hidden = !open;
  tipsStep.classList.toggle('is-open', open);
  tipsStep.setAttribute('aria-expanded', String(open));
}

if (tipsStep && tipsPopover) {
  tipsStep.addEventListener('mouseenter', () => setTipsOpen(true));
  tipsStep.addEventListener('mouseleave', () => setTipsOpen(false));
  tipsStep.addEventListener('focus', () => setTipsOpen(true));
  tipsStep.addEventListener('blur', () => setTipsOpen(false));
  tipsStep.addEventListener('click', (event) => event.preventDefault());
}

fetch(`${API_BASE}/api/health`, { cache: 'no-store' })
  .then((res) => res.ok ? res.json() : Promise.reject(new Error(String(res.status))))
  .then((data) => {
    setServerState(data.ok ? 'ok' : 'bad', data.ok ? 'online' : 'offline');
  })
  .catch(() => {
    setServerState('bad', 'offline');
  });