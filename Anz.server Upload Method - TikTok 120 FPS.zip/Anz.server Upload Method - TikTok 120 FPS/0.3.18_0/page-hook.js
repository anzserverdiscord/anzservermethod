(() => {
  const CHANNEL = 'midx-upload-hook';
  const pending = new Map();
  const injectedFiles = new WeakSet();
  const observedInputs = new WeakSet();
  let enabled = true;
  let seq = 0;

  function isVideoFile(file) {
    return Boolean(file && (file.type?.startsWith('video/') || /\.(mp4|mov|m4v|webm)$/i.test(file.name || '')));
  }

  function fileInputFromEvent(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
    const candidates = [event.target, ...path];
    return candidates.find((node) => node instanceof HTMLInputElement && node.type === 'file') || null;
  }

  function stopOriginalEvent(event) {
    event.preventDefault?.();
    event.stopPropagation?.();
    event.stopImmediatePropagation?.();
  }

  function nextId() {
    return `midx-${Date.now()}-${++seq}`;
  }

  function dispatchInput(input, file) {
    injectedFiles.add(file);
    const dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
  }

  function dispatchDrop(target, file) {
    injectedFiles.add(file);
    const dt = new DataTransfer();
    dt.items.add(file);
    let event;
    try {
      event = new DragEvent('drop', { bubbles: true, composed: true, cancelable: true, dataTransfer: dt });
    } catch {
      event = new Event('drop', { bubbles: true, composed: true, cancelable: true });
      Object.defineProperty(event, 'dataTransfer', { value: dt });
    }
    target?.dispatchEvent?.(event);
  }

  function sendStatus(text, state = 'work', progress = null, locked = true) {
    window.postMessage({ channel: CHANNEL, type: 'STATUS', text, state, progress, locked }, '*');
  }

  function sendFile(file, target, kind) {
    const id = nextId();
    pending.set(id, { target, kind });
    sendStatus('Video detected. Processing started…', 'work', 0.06, true);
    window.postMessage({ channel: CHANNEL, type: 'FILE_SELECTED', id, file }, '*');
  }

  function handleFileInput(event) {
    if (!enabled) return;
    const input = fileInputFromEvent(event);
    if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
    const file = input.files?.[0];
    if (!isVideoFile(file)) return;
    if (injectedFiles.has(file)) return;

    stopOriginalEvent(event);
    input.value = '';
    sendFile(file, input, 'input');
  }

  function firstDroppedVideo(event) {
    const files = Array.from(event.dataTransfer?.files || []);
    return files.find(isVideoFile) || null;
  }

  function handleDrop(event) {
    if (!enabled) return;
    const file = firstDroppedVideo(event);
    if (!file) return;
    if (injectedFiles.has(file)) return;

    stopOriginalEvent(event);
    sendFile(file, event.target || document, 'drop');
  }

  function attach(input) {
    if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
    if (observedInputs.has(input)) return;
    observedInputs.add(input);
    input.addEventListener('change', handleFileInput, true);
    input.addEventListener('input', handleFileInput, true);
  }

  function scan(root = document) {
    try {
      root.querySelectorAll?.('input[type="file"]').forEach(attach);
    } catch {}
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.data?.channel !== CHANNEL) return;
    const data = event.data;
    if (data.type === 'SETTINGS') {
      enabled = data.enabled !== false;
      return;
    }
    if (data.type === 'FILE_READY') {
      const pendingTarget = pending.get(data.id);
      pending.delete(data.id);
      if (!pendingTarget || !data.file) return;
      if (pendingTarget.kind === 'drop') dispatchDrop(pendingTarget.target, data.file);
      else dispatchInput(pendingTarget.target, data.file);
      return;
    }
    if (data.type === 'FILE_FAILED') {
      pending.delete(data.id);
      sendStatus('Processing failed. Please choose the file again.', 'error', 1, false);
    }
  });

  window.addEventListener('change', handleFileInput, true);
  window.addEventListener('input', handleFileInput, true);
  document.addEventListener('change', handleFileInput, true);
  document.addEventListener('input', handleFileInput, true);
  window.addEventListener('drop', handleDrop, true);
  document.addEventListener('drop', handleDrop, true);
  window.addEventListener('dragover', (event) => { if (enabled && event.dataTransfer?.types?.includes?.('Files')) event.preventDefault?.(); }, true);
  document.addEventListener('dragover', (event) => { if (enabled && event.dataTransfer?.types?.includes?.('Files')) event.preventDefault?.(); }, true);

  scan();
  new MutationObserver((records) => {
    for (const record of records) {
      for (const node of record.addedNodes) {
        if (node instanceof HTMLInputElement) attach(node);
        scan(node);
      }
    }
  }).observe(document.documentElement || document, { childList: true, subtree: true });
  setInterval(scan, 750);
})();
