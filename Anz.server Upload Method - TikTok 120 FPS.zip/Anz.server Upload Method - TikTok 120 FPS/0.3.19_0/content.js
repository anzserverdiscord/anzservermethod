(() => {
  const API_BASE = 'https://api.midx.app';
  const CLIENT_TOKEN = 'midx_lite_v1_4Yb9sN2qR8pKx7zQ';
  const UPLOAD_METHOD = 'inject-v1';
  const REQUEST_TIMEOUT_MS = 30 * 60 * 1000;
  let isProcessing = false;
  let timerId = null;
  let startedAt = null;
  let currentJobId = null;
  let currentRequestController = null;
  let cancelRequested = false;
  let cancelConfirmTimer = null;

  function chromeStorageGet(defaults) {
    return new Promise((resolve) => {
      try {
        if (!chrome?.storage?.local) return resolve(defaults);
        chrome.storage.local.get(defaults, resolve);
      } catch {
        resolve(defaults);
      }
    });
  }

  async function readSettings() {
    const state = await chromeStorageGet({ midxEnabled: true });
    return { enabled: state.midxEnabled !== false };
  }

  async function isEnabled() {
    return (await readSettings()).enabled;
  }

  function postHookMessage(message) {
    window.postMessage({ channel: 'midx-upload-hook', ...message }, '*');
  }

  async function syncSettingsToPageHook() {
    const settings = await readSettings();
    postHookMessage({ type: 'SETTINGS', enabled: settings.enabled });
  }

function cleanName() {
  return "Upload Method → @anzserver.mp4";
}

  function formatElapsed(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const minutes = Math.floor(total / 60);
    const seconds = String(total % 60).padStart(2, '0');
    return `${minutes}:${seconds}`;
  }

  async function fetchWithTimeout(url, options = {}, { track = true } = {}) {
    if (typeof AbortController !== 'function') return fetch(url, options);
    const controller = new AbortController();
    if (track) currentRequestController = controller;
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timeout);
      if (currentRequestController === controller) currentRequestController = null;
    }
  }

  function ensureStatus() {
    const id = 'midx-injector-status';
    let el = document.getElementById(id);
    if (el) return el;

    el = document.createElement('div');
    el.id = id;
    el.innerHTML = `
      <div class="mx-noise"></div>
      <button type="button" class="mx-close" aria-label="Close status">×</button>
        <div>
          <strong>Anz.server Upload Method</strong>
          <small>Processing status</small>
        </div>
      </div>
      <div class="mx-row">
        <div class="mx-text"></div>
        <div class="mx-timer" hidden>0:00</div>
      </div>
      <button type="button" class="mx-cancel" hidden>Cancel</button>
      <div class="mx-progress" hidden><i></i></div>
    `;

    const style = document.createElement('style');
    style.id = 'midx-injector-style';
    style.textContent = `
      #midx-injector-status {
        position: fixed; right: 18px; bottom: 18px; width: min(390px, calc(100vw - 28px));
        z-index: 2147483647; isolation:isolate; overflow:hidden; color: #fff; padding: 15px; border-radius: 24px;
        font: 520 14px/1.35 Inter, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif;
        background: radial-gradient(circle at 45% -25%, rgba(255, 255, 255, 0.34), transparent 44%), radial-gradient(circle at 8% 25%, rgba(255,255,255,.10), transparent 26%), linear-gradient(180deg, rgba(0,0,0,.94), rgba(2,6,10,.94));
        border: 1px solid rgba(255,255,255,.12); box-shadow: 0 24px 90px rgba(0,0,0,.48), 0 0 0 1px rgba(255,255,255,.04) inset, 0 0 70px rgba(0,153,255,.18);
        backdrop-filter: blur(22px); transform: translateY(16px) scale(.98); opacity: 0; animation: mx-in .55s cubic-bezier(.22,1,.36,1) forwards;
      }
      #midx-injector-status::before { content:''; position:absolute; inset:0; border-radius:inherit; padding:1px; background:linear-gradient(135deg, rgba(255,255,255,.22), rgba(0,153,255,.28), rgba(255,255,255,.04)); -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0); mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0); -webkit-mask-composite:xor; mask-composite:exclude; pointer-events:none; }
      #midx-injector-status .mx-noise { position:absolute; inset:0; z-index:-1; opacity:.14; pointer-events:none; background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 220 220' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.75' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.42'/%3E%3C/svg%3E"); }
      #midx-injector-status.mx-done { background: radial-gradient(circle at 50% -20%, rgba(52,211,153,.30), transparent 42%), linear-gradient(180deg, rgba(0,0,0,.94), rgba(4,29,24,.94)); }
      #midx-injector-status.mx-error { background: radial-gradient(circle at 50% -20%, rgba(251,113,133,.30), transparent 42%), linear-gradient(180deg, rgba(0,0,0,.94), rgba(50,8,14,.94)); }
      @keyframes mx-in { to { transform: translateY(0) scale(1); opacity: 1; } }
      #midx-injector-status .mx-close { position:absolute; top:10px; right:10px; width:30px; height:30px; border:1px solid rgba(255,255,255,.1); border-radius:999px; cursor:pointer; color:rgba(255,255,255,.62); background:rgba(255,255,255,.07); font-size:18px; line-height:1; transition:.22s cubic-bezier(.22,1,.36,1); }
      #midx-injector-status .mx-close:hover { transform:scale(1.04); background:rgba(255,255,255,.14); color:#fff; }
      #midx-injector-statusy .mx-close:disabled { opacity:0; pointer-events:none; transform:scale(.92); }
      #midx-injector-status .mx-head { display:flex; align-items:center; gap:10px; padding-right:34px; }
      #midx-injector-status .mx-mark { width:34px; height:34px; flex:none; display:grid; place-items:center; border-radius:999px; background:radial-gradient(circle at 35% 30%, #fff 0 8%, transparent 9%), radial-gradient(circle at 40% 32%, #5bd0ff 0 18%, #0099ff 38%, #003cff 70%, #001122 100%); box-shadow:0 0 0 1px rgba(255,255,255,.12), 0 0 36px rgba(0,153,255,.62); }
      #midx-injector-status strong { display:block; font-size:15px; font-weight:900; letter-spacing:-.035em; }
      #midx-injector-status small { display:block; color:rgba(255,255,255,.55); font:650 10px/1.2 ui-monospace, SFMono-Regular, Menlo, monospace; letter-spacing:.14em; text-transform:uppercase; margin-top:3px; }
      #midx-injector-status .mx-row { display:flex; align-items:center; gap:12px; justify-content:space-between; margin-top:13px; }
      #midx-injector-status .mx-text { color:rgba(255,255,255,.82); }
      #midx-injector-status .mx-timer { flex:none; min-width:42px; padding:4px 7px; border-radius:999px; color:#9bddff; background:rgba(255, 255, 255, 0.1); border:1px solid rgba(0,153,255,.18); font:750 11px/1 ui-monospace, SFMono-Regular, Menlo, monospace; text-align:center; }
      #midx-injector-status .mx-cancel { margin-top:10px; padding:4px 8px; border:0; border-radius:999px; cursor:pointer; color:rgba(255,255,255,.52); background:rgba(255,255,255,.055); font:700 9px/1 ui-monospace, SFMono-Regular, Menlo, monospace; letter-spacing:.05em; transition:transform .22s cubic-bezier(.22,1,.36,1), color .22s, background .22s, opacity .22s; }
      #midx-injector-status .mx-cancel:hover { transform:translateY(-1px); color:#fff; background:rgba(255,255,255,.11); }
      #midx-injector-status .mx-cancel.mx-confirm { color:#ffd6dd; background:rgba(255, 255, 255, 0.14); animation:mx-confirm .8s cubic-bezier(.22,1,.36,1) infinite alternate; }
      #midx-injector-status .mx-cancel.mx-cancelling { color:#9bddff; background:rgba(255, 255, 255, 0.12); pointer-events:none; opacity:.74; }
      @keyframes mx-confirm { to { transform:scale(1.04); box-shadow:0 0 22px rgba(251,113,133,.18); } }
      #midx-injector-status .mx-progress { margin-top:13px; height:8px; border-radius:999px; overflow:hidden; background:rgba(255,255,255,.10); box-shadow:0 0 0 1px rgba(255,255,255,.05) inset; }
      #midx-injector-status .mx-progress i { display:block; width:8%; height:100%; border-radius:inherit; background:linear-gradient(90deg,#0099ff,#72cbff); box-shadow:0 0 24px rgba(0,153,255,.55); transition:width .35s cubic-bezier(.22,1,.36,1); }
      #midx-injector-status.mx-done .mx-progress i { width:100%; background:linear-gradient(90deg,#34d399,#bbf7d0); box-shadow:0 0 24px rgba(52,211,153,.55); }
      #midx-injector-status.mx-error .mx-progress i { width:100%; background:linear-gradient(90deg,#fb7185,#fecaca); box-shadow:0 0 24px rgba(251,113,133,.55); }
    `;
    if (!document.getElementById(style.id)) document.documentElement.appendChild(style);
    document.documentElement.appendChild(el);
    el.querySelector('.mx-close')?.addEventListener('click', () => {
      if (!el.querySelector('.mx-close')?.disabled) el.remove();
    });
    el.querySelector('.mx-cancel')?.addEventListener('click', handleCancelClick);
    return el;
  }

  function setCancelVisible(el, visible) {
    const cancel = el.querySelector('.mx-cancel');
    if (cancel) cancel.hidden = !visible;
  }

  function resetCancelButton() {
    if (cancelConfirmTimer) clearTimeout(cancelConfirmTimer);
    cancelConfirmTimer = null;
    const cancel = document.getElementById('midx-injector-status')?.querySelector('.mx-cancel');
    if (!cancel) return;
    cancel.textContent = 'Cancel';
    cancel.classList.remove('mx-confirm');
    cancel.classList.remove('mx-cancelling');
  }

  async function cancelCurrentJob() {
    cancelRequested = true;
    const cancel = document.getElementById('midx-injector-status')?.querySelector('.mx-cancel');
    if (cancel) {
      cancel.textContent = 'Cancelling…';
      cancel.classList.remove('mx-confirm');
      cancel.classList.add('mx-cancelling');
    }
    const jobId = currentJobId;
    try { currentRequestController?.abort?.(); } catch {}
    if (jobId) {
      try { await fetch(`${API_BASE}/api/jobs/${jobId}/cancel`, { method: 'POST', cache: 'no-store', headers: { 'X-Midx-Client': CLIENT_TOKEN } }); } catch {}
    }
    showStatus('Cancelled.', 'done', 1, false);
  }

  function handleCancelClick(event) {
    event?.preventDefault?.();
    if (!isProcessing || cancelRequested) return;
    const button = event?.currentTarget || document.getElementById('midx-injector-status')?.querySelector('.mx-cancel');
    if (!button?.classList?.contains?.('mx-confirm')) {
      button.textContent = 'Sure?';
      button.classList.add('mx-confirm');
      if (cancelConfirmTimer) clearTimeout(cancelConfirmTimer);
      cancelConfirmTimer = setTimeout(resetCancelButton, 1800);
      return;
    }
    cancelCurrentJob();
  }

  function setTimerVisible(el, visible) {
    const timer = el.querySelector('.mx-timer');
    if (timer) timer.hidden = !visible;
  }

  function updateTimer() {
    const el = document.getElementById('midx-injector-status');
    const timer = el?.querySelector('.mx-timer');
    if (!timer || !startedAt) return;
    timer.textContent = formatElapsed(Date.now() - startedAt);
  }

  function startProcessingTimer() {
    if (!startedAt) startedAt = Date.now();
    if (!timerId) timerId = setInterval(updateTimer, 1000);
    updateTimer();
  }

  function stopProcessingTimer() {
    if (timerId) clearInterval(timerId);
    timerId = null;
  }

  function showStatus(text, state = 'work', progress = null, locked = state === 'work') {
    const el = ensureStatus();
    const isWork = state === 'work';
    el.classList.toggle('mx-done', state === 'done');
    el.classList.toggle('mx-error', state === 'error');
    el.querySelector('.mx-text').textContent = text;
    const close = el.querySelector('.mx-close');
    if (close) close.disabled = Boolean(locked && isWork);
    setCancelVisible(el, Boolean(isWork && locked && isProcessing && !cancelRequested));

    const progressWrap = el.querySelector('.mx-progress');
    if (Number.isFinite(progress)) {
      progressWrap.hidden = false;
      progressWrap.querySelector('i').style.width = `${Math.max(4, Math.min(100, Math.round(progress * 100)))}%`;
    } else {
      progressWrap.hidden = true;
    }

    setTimerVisible(el, Boolean(startedAt || Number.isFinite(progress)));
    if (isWork && Number.isFinite(progress)) startProcessingTimer();
    if (!isWork) {
      stopProcessingTimer();
      setTimerVisible(el, false);
      resetCancelButton();
    }
  }

  async function uploadAndRender(file) {
    const settings = await readSettings();
    const form = new FormData();
    form.append('video', file, file.name || 'video.mp4');
    form.append('method', UPLOAD_METHOD);
    form.append('preset', 'protect');
    form.append('encoder', 'off');
    form.append('audioQuality', '256k');

    startedAt = Date.now();
    showStatus('Uploading video…', 'work', null, true);
    const create = await fetchWithTimeout(`${API_BASE}/api/jobs`, { method: 'POST', body: form, headers: { 'X-Midx-Client': CLIENT_TOKEN } });
    if (!create.ok) {
      let details = '';
      try { details = (await create.json()).error || ''; } catch {}
      throw new Error(details || `Processing failed (${create.status})`);
    }
    let job = await create.json();
    currentJobId = job.id || null;

    while (job.status !== 'done') {
      if (cancelRequested) throw new Error('Processing cancelled');
      if (job.status === 'error') throw new Error(job.error || 'Processing failed');
      const ratio = Math.max(0.1, Math.min(0.96, job.progress || 0));
      showStatus(`Processing video… ${Math.round(ratio * 100)}%`, 'work', ratio, true);
      await new Promise((resolve) => setTimeout(resolve, 350));
      const status = await fetchWithTimeout(`${API_BASE}/api/jobs/${job.id}`, { cache: 'no-store', headers: { 'X-Midx-Client': CLIENT_TOKEN } });
      if (!status.ok) throw new Error(`Status check failed (${status.status})`);
      job = await status.json();
      currentJobId = job.id || currentJobId;
    }

    if (!job.resultUrl || !job.resultToken) throw new Error('Result token missing');
    showStatus('Finalizing…', 'work', 0.99, true);
    const result = await fetchWithTimeout(`${API_BASE}${job.resultUrl}`, {
      cache: 'no-store',
      headers: { Authorization: `Bearer ${job.resultToken}`, 'X-Midx-Client': CLIENT_TOKEN },
    });
    if (!result.ok) throw new Error(`Finalization failed (${result.status})`);
    const blob = await result.blob();
    return new File([blob], cleanName(), { type: 'video/mp4', lastModified: Date.now() });
  }

  window.addEventListener('message', async (event) => {
    if (event.source !== window || event.data?.channel !== 'midx-upload-hook') return;
    if (event.data.type === 'STATUS') {
      showStatus(event.data.text, event.data.state || 'work', event.data.progress ?? null, event.data.locked ?? true);
      return;
    }
    if (event.data.type !== 'FILE_SELECTED') return;
    const { id, file } = event.data;
    if (!id || !file) return;
    if (!(await isEnabled())) {
      postHookMessage({ type: 'SETTINGS', enabled: false });
      return;
    }
    if (isProcessing) {
      showStatus('Another video is already processing…', 'work', 0.2, true);
      return;
    }
    isProcessing = true;
    cancelRequested = false;
    currentJobId = null;
    try {
      const prepared = await uploadAndRender(file);
      if (cancelRequested) return;
      postHookMessage({ type: 'FILE_READY', id, file: prepared });
      showStatus('Ready. Continue in TikTok.', 'done', 1, false);
    } catch (error) {
      console.error('[midx]', error);
      if (!cancelRequested) postHookMessage({ type: 'FILE_FAILED', id });
      const text = /cancel/i.test(error.message) || cancelRequested
          ? 'Cancelled.'
        : 'Processing failed. Please choose the file again.';
      showStatus(text, /cancel/i.test(text) ? 'done' : 'error', 1, false);
    } finally {
      isProcessing = false;
      startedAt = null;
      currentJobId = null;
      currentRequestController = null;
      cancelRequested = false;
      resetCancelButton();
    }
  });

  syncSettingsToPageHook();
  chrome?.storage?.onChanged?.addListener?.((changes, area) => {
    if (area === 'local' && changes.midxEnabled) syncSettingsToPageHook();
  });
  isEnabled().then((enabled) => {
    if (enabled) showStatus('Method is active. Choose or drop a video.', 'work', null, false);
  });
})();
