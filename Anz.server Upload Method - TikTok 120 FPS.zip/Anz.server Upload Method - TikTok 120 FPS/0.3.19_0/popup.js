const API_BASE = 'https://api.midx.app';

const toggle = document.getElementById('enabledToggle');
const toggleNote = document.getElementById('toggleNote');
const serverPill = document.getElementById('serverPill');
const serverText = document.getElementById('serverText');
const versionTag = document.getElementById('versionTag');
const tipsStep = document.getElementById('tipsStep');
const tipsPopover = document.getElementById('tipsPopover');

// Son du bouton ON/OFF
const clickSound = new Audio(chrome.runtime.getURL("icons/Anz.server click.wav"));
clickSound.volume = 1;

function setToggleNote(enabled) {
  toggleNote.textContent = enabled
    ? 'Upload Method is active'
    : 'TikTok will receive the original file';
}

function setServerState(state, label) {
  serverPill.classList.remove('ok', 'bad');
  if (state) serverPill.classList.add(state);
  serverText.textContent = label;
}

function hasChromeStorage() {
  return typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
}

function setVersion() {
  try {
    const manifest = chrome.runtime.getManifest();
    const label = manifest.version_name || manifest.version;
    versionTag.textContent = label ? `v${label}` : 'v0.3.15 beta';
  } catch {
    versionTag.textContent = 'v0.3.15 beta';
  }
}

setVersion();

if (hasChromeStorage()) {
  chrome.storage.local.get({ midxEnabled: true }, (state) => {
    toggle.checked = state.midxEnabled !== false;
    setToggleNote(toggle.checked);
  });
} else {
  setToggleNote(toggle.checked);
}

// Son + sauvegarde du bouton ON/OFF
toggle.addEventListener('change', () => {
  clickSound.currentTime = 0;
  clickSound.play().catch(() => {});

  if (hasChromeStorage()) {
    chrome.storage.local.set({ midxEnabled: toggle.checked });
  }

  setToggleNote(toggle.checked);
});

function setTipsOpen(open) {
  if (!tipsStep || !tipsPopover) return;

  tipsPopover.hidden = !open;
  tipsStep.classList.toggle('is-open', open);
  tipsStep.setAttribute('aria-expanded', String(open));
}

if (tipsStep && tipsPopover) {
  tipsStep.addEventListener('mouseenter', () => setTipsOpen(true));
  tipsStep.addEventListener('mouseleave', () => setTipsOpen(false));
  tipsStep.addEventListener('focus', () => setTipsOpen(true));
  tipsStep.addEventListener('blur', () => setTipsOpen(false));
  tipsStep.addEventListener('click', (event) => event.preventDefault());
}

fetch(`${API_BASE}/api/health`, { cache: 'no-store' })
  .then((res) => res.ok ? res.json() : Promise.reject(new Error(String(res.status))))
  .then((data) => {
    setServerState(data.ok ? 'ok' : 'bad', data.ok ? 'online' : 'offline');
  })
  .catch(() => {
    setServerState('bad', 'offline');
  });
  

// ---------------------------
// Check for updates
// ---------------------------

const CURRENT_VERSION = chrome.runtime.getManifest().version;

const translations = {
  en: {
    title: "🚀 Update Available",
    current: "Current version",
    latest: "Latest version",
    question: "Would you like to download the latest version now?"
  },
  fr: {
    title: "🚀 Mise à jour disponible",
    current: "Version actuelle",
    latest: "Dernière version",
    question: "Voulez-vous télécharger la dernière version maintenant ?"
  },
  es: {
    title: "🚀 Actualización disponible",
    current: "Versión actual",
    latest: "Última versión",
    question: "¿Desea descargar la última versión ahora?"
  },
  de: {
    title: "🚀 Update verfügbar",
    current: "Aktuelle Version",
    latest: "Neueste Version",
    question: "Möchten Sie die neueste Version jetzt herunterladen?"
  },
  it: {
    title: "🚀 Aggiornamento disponibile",
    current: "Versione attuale",
    latest: "Ultima versione",
    question: "Vuoi scaricare subito l'ultima versione?"
  },
  pt: {
    title: "🚀 Atualização disponível",
    current: "Versão atual",
    latest: "Última versão",
    question: "Deseja baixar a versão mais recente agora?"
  },
  ru: {
    title: "🚀 Доступно обновление",
    current: "Текущая версия",
    latest: "Последняя версия",
    question: "Хотите скачать последнюю версию сейчас?"
  },
  ja: {
    title: "🚀 アップデートがあります",
    current: "現在のバージョン",
    latest: "最新バージョン",
    question: "今すぐ最新バージョンをダウンロードしますか？"
  },
  ko: {
    title: "🚀 업데이트 가능",
    current: "현재 버전",
    latest: "최신 버전",
    question: "지금 최신 버전을 다운로드하시겠습니까?"
  },
  zh: {
    title: "🚀 有可用更新",
    current: "当前版本",
    latest: "最新版本",
    question: "是否立即下载最新版本？"
  }
};

const lang = chrome.i18n.getUILanguage().split("-")[0];
const t = translations[lang] || translations.en;

fetch("https://raw.githubusercontent.com/anzserverdiscord/anzservermethod/main/version.json")
  .then(r => r.json())
  .then(data => {
    if (data.version !== CURRENT_VERSION) {

      const message =
`${t.title}

${t.current}: ${CURRENT_VERSION}
${t.latest}: ${data.version}

${t.question}`;

      if (confirm(message)) {
        chrome.downloads.download({
          url: data.download,
          filename: "Anz.server Upload Method - TikTok 120 FPS.zip"
        });
      }

    }
  })
  .catch(console.error);